Neil Malhotra				1001084075


This zip file contains all the six programs listed on Lab 2. I have numbered all the different file with question number contained in them.

I have tried to make the output as best as possible, so that it can be easily read. I mostly have instruction with each of the inputs.

Thanks!!

