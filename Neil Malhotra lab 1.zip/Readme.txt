Neil Malhotra          ID:1001084075



I am enclosing both the programs in the zip file icluding this readme.

For the file titled Lab 1 Part 1 

This file contains the program for finding the index number of array of characters corresponding to the equation given in the homework.It uses for loop for taking input and nested for loops 
for comparing the values of squares of the array members to the square of the number x that we took input for.This program asks for the input of 10 integers aand then for x and then finds indexing
of the corresponding members.


For the file titled Lab 1 Part 2


This file contains the program for prime factorization of a number.It has special if condtions for 0 and 1.It has a while loop for all other numbers.The while loop starts checking the 
divisibility with 2, which can be considered smallest prime factor.I have also included 1 as a prime factor for a safe measure. 