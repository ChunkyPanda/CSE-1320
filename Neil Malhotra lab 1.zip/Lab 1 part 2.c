#include <stdio.h>
int main()
{
    
    int n;                                  //Variable declaration for the number to be factorized
	int div,i;                              //Variable declaration for use as divisor and loop
	for(i=0;i<2;i++)    
    {
    printf("Enter number to know its prime factor: ");    
    scanf("%d",&n);                                    // Input for n
    
    printf("\nThe prime factors of %d are: \n\n",n);
    
    div = 2;                                          // Initializing div with 2
    	if(n==0)                                      // Case for when the number is zero
    	{
		printf("No prime factors\n\n");
    	continue;
		}
    	if(n==1)                                      // Case for when the number is 1
    	{
		printf("1\n\n");
    	continue;
		}
    	while(n!=0)                                   // loop for other numbers
	    {
    		if(n%div!=0)                              // if n is divisible by div
            div++;                                    // increment div
        	else  
			{
             n = n / div;                             // reintialize n after dividing it with div
             printf("%d*",div);                       //div will hence be a prime factor
             if(n==1)                                 //terminating condition
                break;                               // break from the loop
			}
    	}
	printf("1\n\n");                                //  1 is a prime factor for all numbers
    }return 0;
}
