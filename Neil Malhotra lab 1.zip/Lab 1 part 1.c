#include<stdio.h>
int main()
{
	int array[10],x,i,j,k;         //Declaration of integer variables
	int y=0;                                      //Intializing integer y with zero 
	for(i=0;i<10;i++)                             //Loop for taking inputs in the array of 10 members
	{
		printf("Enter value for member number ");
		printf("%d :",i+1);
		scanf("%d",&array[i]);
		printf("\n");
	}
	printf("Enter number x:");                    // Taking input for variable x
	scanf("%d",&x);                                     
	for (j=0;j<10;j++)
	{
	for (k=0;k<j;k++)                            //Making nested loop to check all the possible combinations
		{                       
		if(array[k]*array[k]+array[j]*array[j]==x*x)  // If statement checking for the given condition
			{
		 	printf("(%d,%d)",(k+1),(j+1));                // Printing indices
			y++;                                          // Incrementing y if true
			}	
		}
	}	
	if(y==0)                                     // For case when y is zero
	{	printf("There are no such pairs");          // No mathces were found
	}
}

